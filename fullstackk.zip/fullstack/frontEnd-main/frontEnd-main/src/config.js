// Arquivo de configuração para a URL da API

// Define a URL da API que será usada no projeto. Certifique-se de substituir esta URL pela URL real da sua API.
const API_URL = "https://back-end-lista-atividades.onrender.com/api";

// Exporta a URL da API como padrão, para que ela possa ser importada em outros arquivos.
export default API_URL;
